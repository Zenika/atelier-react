'use strict';

var React = require('react');

var Helloworld = React.createClass({

  // TODO define component render function
});

module.exports = Helloworld;
