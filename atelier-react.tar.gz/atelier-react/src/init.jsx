'use strict';

var React = require('react');
var Hello = require('./helloworld/helloworld.component.jsx');

// TODO Render the root element into the view